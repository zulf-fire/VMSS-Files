﻿configuration GroupTest
{
    Import-DscResource -ModuleName PSDesiredStateConfiguration
    Node localhost
    {
        Group GroupTest
        {
            GroupName        = 'IIS_IUSRS'
            Ensure           = 'Present'
            MembersToInclude = 'lothbrok\gmsa1$'
        }
    }
}