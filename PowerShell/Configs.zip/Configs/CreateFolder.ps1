﻿Configuration CreateFolderTestZulfi
{
    Node localhost 
    {
        File TestZulfi 
        {
            Type = 'Directory'
            DestinationPath = 'C:\TestZulfi'
            Ensure = "Present"
        }
    }
}
