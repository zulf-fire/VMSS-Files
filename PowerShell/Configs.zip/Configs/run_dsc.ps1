﻿. C:\Zul\CreateFolderTemp.ps1

CreateFolderTestZulfi -Verbose -OutputPath C:\Configuration

Start-DscConfiguration -Wait -Force -Verbose -Path C:\Configuration