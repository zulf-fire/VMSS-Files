﻿. C:\Config\CreateFolderTemp.ps1

CreateFolderTestZulfi -Verbose -OutputPath C:\Config

Start-DscConfiguration -Wait -Force -Verbose -Path C:\Config