﻿. C:\Config\Configs\CreateFolder.ps1

CreateFolderTestZulfi -Verbose -OutputPath C:\Config -ConfigurationData @{
    AllNodes = @(
        @{NodeName = 'localhost'}
    )
}

Start-DscConfiguration -Wait -Force -Verbose -Path C:\Config -ComputerName localhost