﻿. C:\Configs\CreateFolderTemp.ps1

CreateFolderTestZulfi -Verbose -OutputPath C:\Configs

Start-DscConfiguration -Wait -Force -Verbose -Path C:\Configs