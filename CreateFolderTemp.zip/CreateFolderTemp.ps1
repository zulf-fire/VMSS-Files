﻿Configuration CreateFolderTemp
{
    Node localhost 
    {
        File FolderTemp 
        {
            Type = 'Directory'
            DestinationPath = 'C:\Temp'
            Ensure = "Present"
        }
    }
}