﻿Configuration TempFolder
{
    Node $nodeName 
    {
        File FileDemo 
        {
            Type = 'Directory'
            DestinationPath = 'C:\Temp'
            Ensure = "Present"
        }
    }
}